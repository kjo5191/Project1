package com.lgy.ShoFriend.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
public class InfoController {
	
	@RequestMapping("/my_page")
	public String myPage() {
		log.info("@# my_page()");
		return "my_page";
	}
	
}
