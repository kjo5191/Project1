package com.lgy.ShoFriend.service;

import java.util.HashMap;

public interface InfoService {
	public void updatePwd(HashMap<String, String> param);
	public void updateInfo(HashMap<String, String> param);
	public void updatePwd2(HashMap<String, String> param);
	public void updateInfo2(HashMap<String, String> param);
}
