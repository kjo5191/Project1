package com.lgy.ShoFriend.service;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lgy.ShoFriend.dao.ProductDAO;
import com.lgy.ShoFriend.dto.ProductDTO;

@Service("ProductService")
public class ProductServiceImpl implements ProductService {
    @Autowired
    private SqlSession sqlSession;

    @Override
    public List<ProductDTO> getAllProducts() {
        ProductDAO dao = sqlSession.getMapper(ProductDAO.class);
        return dao.getAllProducts();
    }
    
	@Override
	public List<ProductDTO> getProductListTop10() {
		ProductDAO dao = sqlSession.getMapper(ProductDAO.class);
		return dao.getProductListTop10();
	}
	
	@Override
	public void insertOrder(HashMap<String, String> param) {
		ProductDAO dao = sqlSession.getMapper(ProductDAO.class);
		dao.insertOrder(param);
	}
	
	@Override
	public int getPriceByProductId(int productId) {
		ProductDAO dao = sqlSession.getMapper(ProductDAO.class);
		return dao.getPriceByProductId(productId);
	}	
	
}
